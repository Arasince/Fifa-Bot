import sqlite3
DATABASE = "fifa.db"


class DB_Manager:
    def __init__(self, database):
        self.database = database

    def __select_data(self, sql, data = tuple()):
        conn = sqlite3.connect(self.database)
        with conn:
            cur = conn.cursor()
            cur.execute(sql, data)
            return cur.fetchall()

    def position_values(self,position):
        sql = "SELECT player_name, market_value_million_eur FROM tablo_adi WHERE position = ?"
        return self.__select_data(sql,(position,))
            
    def get_player_info(self, player_name):
        sql = "SELECT * FROM tablo_adi WHERE player_name = ?"
        result = self.__select_data(sql, (player_name,))
        if result:
            # PRAGMA table_info rows: (cid, name, type, notnull, dflt_value, pk)
            columns = [description[1] for description in self.__select_data("PRAGMA table_info(tablo_adi)")]
            return dict(zip(columns, result[0]))
        return None

    def get_nationality(self, player_name):
        sql = "SELECT nationality FROM tablo_adi WHERE player_name = ?"
        result = self.__select_data(sql, (player_name,))
        if result:
            return result[0][0]
        return None

    def get_club_players(self, club_name):
        sql = "SELECT player_name FROM tablo_adi WHERE club = ?"
        return self.__select_data(sql, (club_name,))

if __name__ == '__main__':
    manager = DB_Manager(DATABASE)
