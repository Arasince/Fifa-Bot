import sqlite3
import pandas as pd

csv_file = "fifa_player_performance_market_value.csv"  # Dosya adını kendi dosyanla değiştir
df = pd.read_csv(csv_file, encoding="cp1252")#çalışmazsa encoding="latin1" denenebilir

conn = sqlite3.connect("fifa.db") # Aynı dosya adını .db uzantılı şekilde yaz

df.to_sql("tablo_adi", conn, if_exists="replace", index=False) #tablo_adi kısmı değiştirilebilir

conn.close()
