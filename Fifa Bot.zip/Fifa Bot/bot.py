import discord
from discord.ext import commands
from main import DB_Manager, DATABASE
from config import TOKEN


intents = discord.Intents.default()
intents.message_content = True
bot = commands.Bot(command_prefix='!', intents=intents)
manager = DB_Manager(DATABASE)
MAX_MESSAGE_LEN = 3900


async def send_in_chunks(ctx, text):
    if len(text) <= MAX_MESSAGE_LEN:
        await ctx.send(text)
        return

    current = []
    current_len = 0
    for line in text.splitlines(keepends=True):
        if current_len + len(line) > MAX_MESSAGE_LEN:
            await ctx.send("".join(current))
            current = [line]
            current_len = len(line)
        else:
            current.append(line)
            current_len += len(line)

    if current:
        await ctx.send("".join(current))

@bot.event
async def on_ready():
    print(f'Bot hazır! {bot.user} olarak giriş yapıldı.')

@bot.command(aliases=["footbal"])
async def football(ctx):
    await ctx.send("Mevki Olarak Ne İstersiniz? (Örnek:Defender ,Centre-Back vb.)")
    mesaj = await bot.wait_for("message",check=lambda m: m.author == ctx.author and m.channel == ctx.channel)
    player_values = manager.position_values(mesaj.content)

    if player_values:
        response = f"{mesaj.content} mevkiindeki oyuncuların piyasa değerleri: \n"
        for player in player_values:
            await ctx.send(f"{player[0]}: {player[1]} milyon euro")

    else:
        await ctx.send(f"{mesaj.content} mevkiinde oyuncu bulunamadı")


@bot.command()
async def player_info(ctx, player_name):
    player_info = manager.get_player_info(player_name)
    if player_info:
        response = f"Oyuncu Bilgileri:\n"
        for key, value in player_info.items():
            response += f"{key}: {value}\n"
        await ctx.send(response)
    else:
        await ctx.send(f"{player_name} adında bir oyuncu bulunamadı")

@bot.command()
async def nationality(ctx,player_name):
    await ctx.send(f"{player_name} oyununccu girin ve milliyetini öğrenin(Örnek: Player_1 , Player_2)")
    mesaj = await bot.wait_for("message",check=lambda m: m.author == ctx.author and m.channel == ctx.channel)
    nationality = manager.get_nationality(mesaj.content)
    if nationality:
        await ctx.send(f"{player_name} oyuncunun milliyeti: {nationality}")
    else:
        await ctx.send(f"{player_name} adında bir oyuncu bulunamadı")

@bot.command()
async def club_players(ctx, *, club_name=None):
    if not club_name:
        await ctx.send("Kulüp adını girin (Örnek: Liverpool, Manchester City)")
        mesaj = await bot.wait_for("message", check=lambda m: m.author == ctx.author and m.channel == ctx.channel)
        club_name = mesaj.content.strip()

    club_players = manager.get_club_players(club_name)
    if club_players:
        response = f"{club_name} kulübündeki oyuncular:\n"
        for player in club_players:
            await ctx.send(f"{player[0]}")
    else:
        await ctx.send(f"{club_name} kulübünde oyuncu bulunamadı")

if __name__ == '__main__':
    bot.run(TOKEN)
    
